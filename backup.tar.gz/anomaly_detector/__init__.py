# Anomaly Detector Module
